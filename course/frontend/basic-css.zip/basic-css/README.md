# Basic Css [timing 1h]

## Goals

- Understand Css Basics

## Tasks

- Add a main.css to format the index.html tags element with the follow apparence.

![](images/basic-css.png)
